# 📚 Documentación — AlgoArena

Índice de toda la documentación técnica del proyecto.

## Architecture Decision Records (ADR)

| ID | Título | Estado |
|---|---|---|
| [ADR-001](adr/ADR-001-motor-persistencia.md) | Selección del Motor de Persistencia | ✅ Aceptado |

## Diagramas

| Diagrama | Descripción |
|---|---|
| [C4 Contexto](diagramas/c4-contexto.md) | Actores externos y sistemas dependientes |
| [C4 Contenedores](diagramas/c4-contenedores.md) | Bloques tecnológicos y comunicación |
| [Flujo de Envío](diagramas/flujo-envio.md) | Secuencia completa del ciclo de evaluación |
| [Modelo ER](diagramas/er-modelo-datos.md) | Entidades y relaciones de la base de datos |
| [Stack Tecnológico](diagramas/stack-tecnologico.md) | Componentes del sistema y sus roles |

---

*AlgoArena | Universidad de San Buenaventura Cali | 2026*
