# ⚡ AlgoArena

> Plataforma de programación competitiva inspirada en LeetCode — Universidad de San Buenaventura, Cali 2026.

AlgoArena permite a los estudiantes resolver problemas de programación, enviar soluciones, ejecutar código contra casos de prueba y visualizar su progreso. Construida con Flask, PostgreSQL y Judge0.

---

## 👥 Equipo

| Integrante | Rol |
|---|---|
| Juan Pablo Perlaza | Arquitectura & Backend |
| Juan Felipe Vergara | Backend & Base de Datos |
| Brayan Stiven Agudelo | Backend & Integración |

**Docente:** Iván Mauricio Cabezas — Laboratorio de Software

---

## 🛠️ Stack Tecnológico

| Componente | Tecnología | Versión |
|---|---|---|
| Lenguaje | Python | 3.12 |
| Framework web | Flask | 3.x |
| ORM | SQLAlchemy | 2.x |
| Migraciones | Alembic | 1.x |
| Base de datos | PostgreSQL | 16 |
| Autenticación | Flask-JWT-Extended | 4.x |
| Juez de código | Judge0 CE | — |

```mermaid
graph TD
    subgraph Frontend
        A[React / HTML]
    end

    subgraph Backend["Backend — Python 3.12"]
        B[Flask 3.x\nAPI REST]
        C[Flask-JWT-Extended 4.x\nAutenticación]
        D[SQLAlchemy 2.x\nORM]
        E[Alembic 1.x\nMigraciones]
    end

    subgraph Persistencia
        F[(PostgreSQL 16)]
    end

    subgraph Externo
        G[Judge0 CE\nEjecución de Código]
    end

    A -->|HTTP/JSON| B
    B --> C
    B --> D
    D --> E
    D --> F
    B -->|HTTP/REST| G
```

---

## 🏛️ Arquitectura C4

### Nivel 1 — Contexto del Sistema

```mermaid
C4Context
    title AlgoArena — Diagrama de Contexto (C4 Nivel 1)

    Person(estudiante, "Estudiante", "Resuelve problemas de programación y envía soluciones.")
    Person(admin, "Administrador", "Gestiona problemas, casos de prueba y usuarios.")

    System(algoarena, "AlgoArena", "Plataforma de programación competitiva. Permite resolver problemas, ejecutar código y visualizar resultados.")

    System_Ext(judge0, "Judge0 CE", "Servicio externo de ejecución de código en entorno aislado.")

    Rel(estudiante, algoarena, "Consulta problemas, envía soluciones", "HTTPS")
    Rel(admin, algoarena, "Administra contenido y usuarios", "HTTPS")
    Rel(algoarena, judge0, "Envía código para evaluación", "HTTP/REST")
```

### Nivel 2 — Contenedores

```mermaid
C4Container
    title AlgoArena — Diagrama de Contenedores (C4 Nivel 2)

    Person(estudiante, "Estudiante")
    Person(admin, "Administrador")

    System_Boundary(algoarena, "AlgoArena") {
        Container(frontend, "Web Browser / Cliente", "React / HTML", "Interfaz de usuario. Permite registrarse, consultar problemas y enviar soluciones.")
        Container(api, "API Flask", "Flask 3.x + Python 3.12", "Lógica de negocio. Expone endpoints REST y coordina los demás servicios.")
        Container(auth, "Servicio de Autenticación", "Flask-JWT-Extended 4.x", "Emite y valida tokens JWT para controlar el acceso.")
        ContainerDb(db, "Base de Datos", "PostgreSQL 16", "Almacena usuarios, problemas, casos de prueba, envíos y progreso.")
    }

    System_Ext(judge0, "Servicio Juez", "Judge0 CE — Ejecuta código en entorno aislado.")

    Rel(estudiante, frontend, "Usa", "HTTPS")
    Rel(admin, frontend, "Administra", "HTTPS")
    Rel(frontend, api, "Peticiones REST", "HTTP/JSON")
    Rel(api, auth, "Valida token JWT", "Interno")
    Rel(api, db, "Lee y escribe datos", "SQLAlchemy / SQL")
    Rel(api, judge0, "Envía código + casos de prueba", "HTTP/REST")
    Rel(judge0, api, "Retorna resultado JSON", "HTTP/REST")
```

---

## 🔄 Flujo de Envío de Código

```mermaid
sequenceDiagram
    actor Usuario
    participant Frontend
    participant API as API Flask
    participant Auth as Servicio Auth
    participant DB as PostgreSQL
    participant Judge as Judge0 CE

    Usuario->>Frontend: Enviar solución
    Frontend->>API: POST /submit (código + problema_id)
    API->>Auth: Validar token JWT
    Auth-->>API: Token válido
    API->>DB: GET problema + casos_de_prueba
    DB-->>API: Datos del problema
    API->>Judge: Ejecutar código contra casos de prueba
    Judge-->>API: Resultado estructurado (JSON)
    API->>DB: INSERT envío (resultado_juez JSONB)
    API->>DB: UPDATE progreso_usuario
    API-->>Frontend: Respuesta con resultado
    Frontend-->>Usuario: Mostrar veredicto
```

---

## 🗄️ Modelo de Datos (ER)

```mermaid
erDiagram
    USUARIOS {
        varchar id PK
        varchar nombre_usuario
        varchar correo
        varchar contrasena_hash
        varchar rol
        timestamp creado_en
    }

    PROBLEMAS {
        varchar id PK
        varchar titulo
        varchar slug
        text descripcion
        varchar dificultad
        varchar[] etiquetas
        timestamp creado_en
    }

    ENVIOS {
        varchar id PK
        varchar usuario_id FK
        varchar problema_id FK
        text codigo
        varchar lenguaje
        varchar estado
        jsonb resultado_juez
        float tiempo_ejecucion_ms
        timestamp enviado_en
    }

    CASOS_DE_PRUEBA {
        varchar id PK
        varchar problema_id FK
        text entrada
        text salida_esperada
        boolean es_publico
    }

    PROGRESO_USUARIO {
        varchar id PK
        varchar usuario_id FK
        varchar problema_id FK
        boolean resuelto
        integer intentos
        timestamp ultimo_intento
    }

    USUARIOS ||--o{ ENVIOS : "realiza"
    USUARIOS ||--o{ PROGRESO_USUARIO : "tiene"
    PROBLEMAS ||--o{ ENVIOS : "recibe"
    PROBLEMAS ||--o{ CASOS_DE_PRUEBA : "contiene"
    PROBLEMAS ||--o{ PROGRESO_USUARIO : "registra"
```

---

## 📁 Estructura del Proyecto

```
AlgoArena/
├── docs/
│   ├── adr/
│   │   └── ADR-001-motor-persistencia.md
│   └── diagramas/
│       ├── c4-contexto.md
│       ├── c4-contenedores.md
│       ├── flujo-envio.md
│       ├── er-modelo-datos.md
│       └── stack-tecnologico.md
├── src/
│   ├── app/
│   │   ├── models/
│   │   ├── routes/
│   │   └── services/
│   ├── migrations/
│   └── config.py
└── README.md
```

---

## 📚 Documentación

- [ADR-001 — Selección del Motor de Persistencia](docs/adr/ADR-001-motor-persistencia.md)
- [Diagrama C4 Contexto](docs/diagramas/c4-contexto.md)
- [Diagrama C4 Contenedores](docs/diagramas/c4-contenedores.md)
- [Flujo de Envío de Código](docs/diagramas/flujo-envio.md)
- [Modelo de Datos ER](docs/diagramas/er-modelo-datos.md)

---

## 🚀 Referencias

- [PostgreSQL 16 Docs](https://www.postgresql.org/docs/16/)
- [SQLAlchemy 2.x Docs](https://docs.sqlalchemy.org/en/20/)
- [Flask 3.x Docs](https://flask.palletsprojects.com/)
- [Flask-Migrate / Alembic](https://flask-migrate.readthedocs.io/)
- [Judge0 API](https://judge0.com/)

---

*AlgoArena | Universidad de San Buenaventura Cali | Laboratorio de Software 2026*
